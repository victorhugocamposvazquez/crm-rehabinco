/**
 * Copiar a `app/api/estudio/caption/route.ts`.
 * Genera el texto de la publicación en servidor para no exponer la clave del modelo.
 */
import { buildCaptionPrompt, captionFallback, type CaptionRequest } from './caption';

/** TODO(Cursor): conectar con el proveedor de IA que ya usa el copiloto del CRM y devolver el texto. */
async function generateText(_prompt: string): Promise<string> {
  throw new Error('generateText sin implementar');
}

export async function POST(req: Request) {
  // TODO(Cursor): comprobar sesión de Supabase y que el usuario puede ver el inmueble.
  const body = (await req.json()) as CaptionRequest;
  try {
    const text = await generateText(buildCaptionPrompt(body));
    return Response.json({ text, source: 'ia' });
  } catch {
    return Response.json({ text: captionFallback(body), source: 'plantilla' });
  }
}
