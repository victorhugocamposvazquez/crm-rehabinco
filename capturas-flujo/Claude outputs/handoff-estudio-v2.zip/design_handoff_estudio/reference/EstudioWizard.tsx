'use client';
/**
 * Estudio · asistente para crear una publicación (imagen suelta o carrusel) de un inmueble.
 * Pasos: 1 Inmueble → 2 Diseño → 3 Editar → 4 Publicar. «Vista previa» es un botón, no un paso.
 *
 * Referencia funcional de `Estudio.dc.html`. Los estilos van en línea con los valores del diseño para comparar;
 * al integrar, cambia `k` por los tokens del CRM (claro / oscuro) y los botones por los de `components/ui`.
 * La lógica (estado, pantallas, deshacer, exportar, publicar) es la definitiva.
 */
import { useMemo, useRef, useState, type CSSProperties, type DragEvent, type ReactNode } from 'react';
import { ArrowLeft, Check, ChevronLeft, ChevronRight, Copy, Database, Download, Eye, EyeOff, Image as ImageIcon, LayoutTemplate, Palette, Plus, Redo2, Search, Send, Sparkles, Trash2, Undo2, X } from 'lucide-react';
import { FIELD_LABELS, FORMATS, GOALS, MAX_SLIDES, READONLY_FIELDS, TEMPLATES, THEMES, TYPOS, fitBox, templatesForGoal, type FieldKey, type FormatId, type TemplateId, type ThemeId, type TypoId } from './config';
import { assignPhoto, baseFields, buildSlideData, defaultHidden, initialPublication, makeSlide, resolveSlots, slideLabel, usedPhotoIndexes, type InmuebleEstudio, type Publication } from './data';
import { Creative } from './templates';
import { usePublication } from './usePublication';
import { downloadBlob, exportSlides, slideFilename } from './exportCreative';
import { captionFallback, type Canal, type CaptionRequest, type Tono } from './caption';

/** Tokens. TODO(Cursor): sustituir por las variables del CRM; el prototipo tiene versión clara y oscura (Estudio.dc.html › tweak «tema»). */
const k = {
  bg: '#F5F5F4', glass: 'rgba(245,245,244,.9)', panel: '#FFFFFF', hover: '#EFEFEE', line: '#E4E4E7', line2: '#D4D4D8', fg: '#0A0A0A', mut: '#52525B',
  prim: '#0A0A0A', primFg: '#FFFFFF', stage: '#DCD9D3', chip: '#ECECEA', blue: '#4C8DFF', link: '#1D4ED8', danger: '#B42318', dangerBg: '#FCEEEC', dotOff: '#8F8B84', warn: '#8A5A00',
};
const eur = (n: number) => n.toLocaleString('es-ES') + ' €';
const STEPS = [['inmueble', 'Inmueble'], ['diseno', 'Diseño'], ['editar', 'Editar'], ['publicar', 'Publicar']] as const;
type Step = (typeof STEPS)[number][0];
type Tab = 'diseno' | 'datos' | 'fotos' | 'estilo';
const btn: CSSProperties = { font: 'inherit', color: 'inherit', border: 0, background: 'none', cursor: 'pointer', padding: 0, textAlign: 'left' };
const stage: CSSProperties = { background: k.stage, backgroundImage: 'radial-gradient(rgba(0,0,0,.06) 1px, transparent 1px)', backgroundSize: '18px 18px' };
const tplName = (t: TemplateId) => TEMPLATES.find((x) => x.id === t)?.nombre ?? t;
const pantallas = (n: number) => (n === 1 ? '1 pantalla' : `${n} pantallas`);

export type PublishPayload = { inmuebleId: string; publication: Publication; images: Partial<Record<FormatId, Blob[]>>; caption: string };
export type EstudioWizardProps = {
  inmuebles: InmuebleEstudio[];
  /** Desde la ficha: el inmueble viene elegido y se abre en el paso 2. */
  initialInmuebleId?: string;
  /** Sube las imágenes a Storage y guarda la fila en `publicaciones`. */
  onSave?: (p: PublishPayload) => Promise<void> | void;
  /** Sube las imágenes, guarda y llama a /api/estudio/publicar. Debe lanzar un error si falla. */
  onPublish?: (p: PublishPayload) => Promise<void>;
};

export function EstudioWizard({ inmuebles, initialInmuebleId, onSave, onPublish }: EstudioWizardProps) {
  const [pid, setPid] = useState(initialInmuebleId ?? inmuebles[0]?.id ?? '');
  const [step, setStep] = useState<Step>(initialInmuebleId ? 'diseno' : 'inmueble');
  const P = usePublication();
  const { pub } = P;
  const [cur, setCur] = useState(0);
  const [sel, setSel] = useState('');
  const [tab, setTab] = useState<Tab>('datos');
  const [addOpen, setAddOpen] = useState<false | 'top' | 'bottom'>(false);
  const [pvOpen, setPvOpen] = useState(false);
  const [pv, setPv] = useState(0);
  const [extra, setExtra] = useState<Partial<Record<FormatId, boolean>>>({});
  const [canal, setCanal] = useState<Canal>('instagram');
  const [tono, setTono] = useState<Tono>('cercano');
  const [caption, setCaption] = useState('');
  const [busy, setBusy] = useState<'' | 'caption' | 'export' | 'publish'>('');
  const [toast, setToast] = useState<{ msg: string; undo?: boolean } | null>(null);
  const toastT = useRef<ReturnType<typeof setTimeout>>(undefined);
  const dragFrom = useRef(-1);
  const exportRefs = useRef<Partial<Record<FormatId, (HTMLDivElement | null)[]>>>({});

  const inm = inmuebles.find((i) => i.id === pid);
  const slideData = useMemo(() => (inm ? pub.slides.map((s) => buildSlideData(inm, pub, s)) : []), [inm, pub]);
  if (!inm) return <p style={{ padding: 32, color: k.mut }}>No hay inmuebles con fotos para crear una publicación.</p>;

  const n = pub.slides.length;
  const c = Math.min(cur, n - 1);
  const slide = pub.slides[c];
  const tpl = TEMPLATES.find((t) => t.id === slide.template)!;
  const data = slideData[c];
  const nF = inm.fotos.length;
  const label = (i: number) => slideLabel(inm, pub.slides[i], tplName);
  const full = n >= MAX_SLIDES;
  const goal = GOALS.find((g) => g.id === pub.goal)!;
  const fmt = FORMATS[pub.format];
  const fmtName = pub.format === 'feed' ? 'Instagram 4:5' : pub.format === 'post' ? 'Cuadrado 1:1' : `${fmt.label} ${fmt.ratio}`;
  const si = STEPS.findIndex((s) => s[0] === step);

  const showToast = (msg: string, undo?: boolean) => { clearTimeout(toastT.current); setToast({ msg, undo }); toastT.current = setTimeout(() => setToast(null), undo ? 6000 : 2400); };
  const go = (s: Step) => { setStep(s); setSel(''); setAddOpen(false); };
  const goTo = (i: number) => { setCur(Math.max(0, Math.min(n - 1, i))); setSel(''); setAddOpen(false); };
  const onSelect = (key: string) => { setSel(key); setAddOpen(false); if (key) setTab(key.startsWith('foto') ? 'fotos' : 'datos'); };

  // ---- pantallas ----
  const insertAfterCurrent = (t: TemplateId, photo: number | null) => { const at = P.insertAfter(c, makeSlide(t, photo)); setCur(at); setSel(''); setAddOpen(false); };
  const removeCurrent = () => { if (n === 1) return; const lbl = label(c), num = c + 1; P.remove(c); setCur(Math.max(0, c - 1)); setSel(''); showToast(`Pantalla ${num} eliminada (${lbl})`, true); };
  const onDrop = (to: number) => (e: DragEvent) => { e.preventDefault(); if (dragFrom.current >= 0) { P.move(dragFrom.current, to); setCur(to); } dragFrom.current = -1; };

  // ---- datos de la pantalla actual ----
  const toggleField = (f: FieldKey) => { P.editSlide(c, (s) => ({ hidden: { ...s.hidden, [f]: !s.hidden[f] } })); if (sel === f) setSel(''); };
  const setField = (f: FieldKey, v: string) => P.editSlide(c, (s) => ({ overrides: { ...s.overrides, [f]: v } }), `type:${f}:${slide.id}`);
  const resetField = (f: FieldKey) => P.editSlide(c, (s) => { const o = { ...s.overrides }; delete o[f]; return { overrides: o }; });
  const selFoto = sel.startsWith('foto');
  const slotSel = selFoto ? Math.min(Number(sel.slice(4)) || 0, tpl.fotos - 1) : 0;
  const selKey = !selFoto && sel && !slide.hidden[sel as FieldKey] ? (sel as FieldKey) : null;
  const nHid = tpl.uses.filter((f) => slide.hidden[f]).length;
  const slotName = (i: number) => (tpl.fotos === 1 ? 'Foto' : i === 0 ? 'Foto principal' : `Foto ${i + 1}`);

  // ---- objetivo y diseño de la imagen principal (paso 2) ----
  const pickGoal = (id: typeof pub.goal) => P.edit((p) => {
    const own = TEMPLATES.find((t) => t.only === id)?.id;
    const first = p.slides[0], stale = !!TEMPLATES.find((t) => t.id === first.template)?.only && TEMPLATES.find((t) => t.id === first.template)?.only !== id;
    const t = own ?? (stale ? 'galeria' : first.template);
    return { goal: id, slides: p.slides.map((s, i) => (i === 0 ? { ...s, template: t, hidden: defaultHidden(t) } : s)) };
  });
  const pickCoverTemplate = (t: TemplateId) => { P.editSlide(0, (s) => ({ template: t, hidden: s.template === t ? s.hidden : defaultHidden(t) })); setCur(0); setTab('datos'); go('editar'); };
  const pickInmueble = (id: string) => { if (id !== pid) { setPid(id); P.reset({ ...initialPublication(pub.slides[0].template), format: pub.format, theme: pub.theme, typo: pub.typo, goal: pub.goal }); setCur(0); setCaption(''); } go('diseno'); };

  // ---- texto, exportar, publicar ----
  const captionReq = (): CaptionRequest => ({
    inmueble: { ref: inm.ref, titulo: slideData[0].f.titulo, direccion: inm.direccion, zona: inm.zona, barrio: inm.barrio, precio: inm.precio, m2: inm.m2, habitaciones: inm.habitaciones, banos: inm.banos, energia: inm.energia, agente: inm.agente.nombre },
    canal, tono, objetivo: slideData[0].f.badge,
    // Solo datos visibles en alguna pantalla.
    visibles: Array.from(new Set(pub.slides.flatMap((s) => TEMPLATES.find((t) => t.id === s.template)!.uses.filter((f) => !s.hidden[f])))),
    soloZona: pub.soloZona,
  });
  const generateCaption = async () => {
    setBusy('caption');
    try { const r = await fetch('/api/estudio/caption', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(captionReq()) }); setCaption(r.ok ? ((await r.json()) as { text: string }).text : captionFallback(captionReq())); }
    catch { setCaption(captionFallback(captionReq())); } finally { setBusy(''); }
  };
  const formatsOut = [pub.format, ...(Object.keys(extra) as FormatId[]).filter((f) => extra[f] && f !== pub.format)];
  const nImages = n * formatsOut.length;
  const renderImages = async () => {
    const images: Partial<Record<FormatId, Blob[]>> = {};
    for (const f of formatsOut) images[f] = await exportSlides((exportRefs.current[f] ?? []).map((el) => el?.firstElementChild as HTMLElement).filter(Boolean), f);
    return images;
  };
  const download = async () => {
    setBusy('export');
    try { const images = await renderImages(); for (const f of formatsOut) images[f]!.forEach((b, i) => downloadBlob(b, slideFilename(inm.ref, f, i))); await onSave?.({ inmuebleId: inm.id, publication: pub, images, caption }); }
    finally { setBusy(''); }
  };
  const save = async () => { setBusy('export'); try { await onSave?.({ inmuebleId: inm.id, publication: pub, images: await renderImages(), caption }); showToast(`Guardada en ${inm.ref}`); } finally { setBusy(''); } };
  const publish = async () => {
    setBusy('publish');
    try { await onPublish?.({ inmuebleId: inm.id, publication: pub, images: await renderImages(), caption }); showToast(n === 1 ? 'Publicada en Instagram' : `Carrusel de ${n} publicado en Instagram`); }
    catch (e) { showToast(`No se pudo publicar: ${(e as Error).message}`); } finally { setBusy(''); }
  };

  // ---- medidas ----
  const [gw, gh] = fitBox(pub.format, 220, 268);
  const [cw, ch] = fitBox(pub.format, 440, 420);
  const peekW = Math.round(cw * .82), peekH = Math.round(ch * .82);
  const [mw, mh] = fitBox(pub.format, 78, 82);
  const [tw, th] = fitBox(pub.format, 76, 76);
  const [aw, ah] = fitBox(pub.format, 64, 64);
  const phoneW = 320, phoneH = Math.min(Math.round(phoneW * fmt.h / fmt.w), 520);
  const coverTemplates = templatesForGoal(pub.goal);
  const slideTemplates = templatesForGoal(pub.goal, { includeSlideOnly: true });
  const used = usedPhotoIndexes(pub, nF);
  const stepVal: Record<Step, string> = { inmueble: inm.ref, diseno: `${goal.label} · ${tplName(pub.slides[0].template)}`, editar: n === 1 ? '1 imagen' : `Carrusel de ${n}`, publicar: 'Texto y salida' };
  const stepHint: Record<Step, string> = { inmueble: 'Elige el inmueble', diseno: 'Qué anuncias y diseño', editar: stepVal.editar, publicar: 'Texto y salida' };

  const pill = (on: boolean): CSSProperties => ({ ...btn, height: 34, padding: '0 12px', borderRadius: 9, border: `1px solid ${on ? k.fg : k.line2}`, background: on ? k.chip : 'transparent', color: on ? k.fg : k.mut, fontSize: 13, fontWeight: 600 });
  const sideBtn = (o: CSSProperties = {}): CSSProperties => ({ ...btn, width: 86, borderRadius: 12, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, padding: '0 6px', fontSize: 12.5, fontWeight: 600, lineHeight: 1.3, textAlign: 'center', ...o });
  const iconBtn = (o: CSSProperties = {}): CSSProperties => ({ ...btn, width: 34, height: 34, borderRadius: 9, display: 'grid', placeItems: 'center', ...o });
  const deleteBtn = (small = false) => n > 1 && (
    <button onClick={removeCurrent} aria-label={`Eliminar la pantalla ${c + 1}: ${label(c)}`} style={{ ...btn, display: 'flex', alignItems: 'center', gap: 6, height: small ? 32 : 34, padding: '0 11px 0 8px', borderRadius: 9, border: `1px solid ${k.line2}`, background: k.panel, fontSize: small ? 12.5 : 13, fontWeight: 600, color: k.danger }}><Trash2 size={15} />Eliminar pantalla {c + 1}</button>
  );
  const addPanel = (pos: 'top' | 'bottom') => addOpen === pos && (
    <div role="dialog" aria-label="Añadir pantalla" style={{ position: 'absolute', zIndex: 25, width: 'calc(100% - 32px)', maxWidth: 760, padding: '14px 16px 16px', borderRadius: 16, border: `1px solid ${k.line2}`, background: k.panel, boxShadow: '0 20px 60px rgba(0,0,0,.25)', ...(pos === 'top' ? { left: '50%', transform: 'translateX(-50%)', top: 58 } : { left: 16, bottom: '100%', marginBottom: 8 }) }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}><b style={{ fontSize: 14 }}>Añadir después de la pantalla {c + 1}</b><button onClick={() => setAddOpen(false)} aria-label="Cerrar" style={iconBtn({ width: 28, height: 28, color: k.mut })}><X size={16} /></button></div>
      <div style={{ fontSize: 12, color: k.mut, marginBottom: 6 }}>Una foto del inmueble</div>
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 6, marginBottom: 10 }}>
        {inm.fotos.map((p, i) => (
          <button key={p.id} onClick={() => insertAfterCurrent('foto', i)} title={p.nombre} style={{ ...btn, flex: '0 0 auto', width: 84 }}>
            <span style={{ position: 'relative', display: 'block', width: 84, height: 64, borderRadius: 9, backgroundImage: `url("${p.url}")`, backgroundSize: 'cover', backgroundPosition: 'center', opacity: used.includes(i) ? .55 : 1 }}>{used.includes(i) && <span style={{ position: 'absolute', right: 4, top: 4, fontSize: 10, fontWeight: 700, padding: '2px 6px', borderRadius: 6, background: 'rgba(0,0,0,.7)', color: '#fff' }}>Ya está</span>}</span>
            <span style={{ display: 'block', fontSize: 11.5, marginTop: 4, textAlign: 'center', color: k.mut }}>{p.nombre}</span>
          </button>
        ))}
      </div>
      <div style={{ fontSize: 12, color: k.mut, marginBottom: 6 }}>Un diseño con datos</div>
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto' }}>
        {slideTemplates.filter((t) => t.id !== 'foto').map((t) => (
          <button key={t.id} onClick={() => insertAfterCurrent(t.id, t.id === 'contacto' ? 0 : null)} title={t.nombre} style={{ ...btn, flex: '0 0 auto', width: 84, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
            <span style={{ display: 'grid', placeItems: 'center', width: 84, height: 76, borderRadius: 9, background: k.stage, lineHeight: 0 }}><Creative template={t.id} data={buildSlideData(inm, pub, makeSlide(t.id, t.id === 'contacto' ? 0 : null))} width={aw} height={ah} /></span>
            <span style={{ fontSize: 11.5, color: k.mut, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: 84 }}>{t.nombre}</span>
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100%', background: k.bg, color: k.fg }}>
      {/* Pasos: cada uno enseña lo ya elegido */}
      <ol aria-label="Pasos" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, flexWrap: 'wrap', listStyle: 'none', margin: 0, padding: '12px 24px', borderBottom: `1px solid ${k.line}` }}>
        {STEPS.map(([id, lbl], i) => { const on = i === si, done = i < si; return (
          <li key={id} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <button onClick={() => go(id)} aria-current={on ? 'step' : undefined} style={{ ...btn, display: 'flex', alignItems: 'center', gap: 9, height: 44, padding: '0 14px 0 8px', borderRadius: 999, background: on ? k.chip : 'transparent', color: on || done ? k.fg : k.mut }}>
              <span style={{ width: 26, height: 26, borderRadius: '50%', display: 'grid', placeItems: 'center', fontSize: 12.5, fontWeight: 700, background: on ? k.prim : done ? k.blue : 'transparent', color: on ? k.primFg : done ? '#fff' : k.mut, border: `1px solid ${on || done ? 'transparent' : k.line2}` }}>{done ? <Check size={15} /> : i + 1}</span>
              <span style={{ lineHeight: 1.2 }}><span style={{ display: 'block', fontSize: 13.5, fontWeight: 600 }}>{lbl}</span><span style={{ display: 'block', fontSize: 11.5, opacity: .8, maxWidth: 170, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{done ? stepVal[id] : stepHint[id]}</span></span>
            </button>
            {i < STEPS.length - 1 && <span aria-hidden style={{ width: 22, height: 2, borderRadius: 2, background: done ? k.blue : k.line2 }} />}
          </li>); })}
      </ol>

      {/* 1 · Inmueble: elegir avanza solo */}
      {step === 'inmueble' && (
        <main style={{ padding: '32px 28px 120px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 16, flexWrap: 'wrap', marginBottom: 22 }}>
            <div><h1 style={{ fontSize: 26, margin: 0, fontWeight: 600 }}>¿De qué inmueble es la publicación?</h1><p style={{ margin: '6px 0 0', color: k.mut, fontSize: 14 }}>Al elegirlo pasas al siguiente paso.</p></div>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, width: 320, maxWidth: '100%', height: 42, padding: '0 12px', border: `1px solid ${k.line2}`, borderRadius: 11, color: k.mut }}><Search size={16} /><input placeholder="Referencia, dirección o zona" aria-label="Buscar inmueble" style={{ border: 0, outline: 0, background: 'none', flex: 1, fontSize: 14, color: k.fg }} /></label>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(270px,1fr))', gap: 18 }}>
            {inmuebles.map((p) => (
              <button key={p.id} onClick={() => pickInmueble(p.id)} aria-pressed={p.id === pid} className="estudio-card" style={{ ...btn, display: 'block', borderRadius: 16, overflow: 'hidden', background: k.panel, border: `1.5px solid ${p.id === pid ? k.blue : k.line}` }}>
                <span style={{ display: 'block', aspectRatio: '16/10', backgroundImage: p.fotos[0] ? `url("${p.fotos[0].url}")` : 'none', backgroundSize: 'cover', backgroundPosition: 'center' }} />
                <span style={{ display: 'block', padding: '14px 16px 16px' }}>
                  <span style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 12.5, color: k.mut }}>{p.ref}</span><b style={{ fontSize: 17 }}>{eur(p.precio)}</b></span>
                  <span style={{ display: 'block', fontSize: 15.5, fontWeight: 600, marginTop: 6 }}>{p.titulo}</span>
                  <span style={{ display: 'block', fontSize: 13, color: k.mut, marginTop: 3 }}>{p.zona} · {p.m2} m² · {p.fotos.length} fotos</span>
                </span>
              </button>
            ))}
          </div>
        </main>
      )}

      {/* 2 · Diseño de la imagen principal. Se empieza con UNA imagen. */}
      {step === 'diseno' && (
        <main style={{ padding: '28px 28px 120px' }}>
          <h1 style={{ fontSize: 26, margin: '0 0 14px', fontWeight: 600 }}>¿Qué quieres anunciar?</h1>
          <div role="radiogroup" aria-label="Objetivo" style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 28 }}>
            {GOALS.filter((g) => g.id !== 'bajada' || (inm.precioAnterior ?? 0) > inm.precio).map((g) => { const on = g.id === pub.goal; return (
              <button key={g.id} role="radio" aria-checked={on} onClick={() => pickGoal(g.id)} style={{ ...btn, height: 42, padding: '0 18px', borderRadius: 999, border: `1px solid ${on ? k.prim : k.line2}`, background: on ? k.prim : 'transparent', color: on ? k.primFg : k.fg, fontSize: 14.5, fontWeight: 600 }}>{g.label}</button>); })}
          </div>
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: '14px 24px', flexWrap: 'wrap', marginBottom: 18, paddingTop: 22, borderTop: `1px solid ${k.line}` }}>
            <div><h2 style={{ fontSize: 20, margin: 0, fontWeight: 600 }}>Elige el diseño de la imagen principal</h2><p style={{ margin: '5px 0 0', color: k.mut, fontSize: 14 }}>Empiezas con una sola imagen. Después, si quieres, le añades fotos y un cierre para convertirla en carrusel.</p></div>
            <div style={{ display: 'flex', gap: '10px 16px', flexWrap: 'wrap', alignItems: 'center' }}>
              <div role="radiogroup" aria-label="Formato" style={{ display: 'flex', gap: 4 }}>
                {(['feed', 'post', 'story', 'fb'] as FormatId[]).map((f) => <button key={f} role="radio" aria-checked={pub.format === f} onClick={() => P.edit({ format: f })} style={pill(pub.format === f)}>{f === 'feed' ? 'Instagram' : f === 'post' ? 'Cuadrado' : FORMATS[f].label} <span style={{ opacity: .7, fontWeight: 400 }}>{FORMATS[f].ratio}</span></button>)}
              </div>
              <ThemeDots value={pub.theme} onPick={(t) => P.edit({ theme: t })} />
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(240px,1fr))', gap: 20 }}>
            {coverTemplates.map((t) => { const on = pub.slides[0].template === t.id; return (
              <button key={t.id} onClick={() => pickCoverTemplate(t.id)} aria-pressed={on} className="estudio-card" style={{ ...btn, display: 'block', borderRadius: 16, overflow: 'hidden', background: k.panel, border: `1.5px solid ${on ? k.blue : k.line}` }}>
                <span style={{ ...stage, position: 'relative', display: 'grid', placeItems: 'center', height: 300, padding: 16 }}>
                  <span style={{ display: 'block', lineHeight: 0, boxShadow: '0 14px 34px rgba(0,0,0,.3)' }}><Creative template={t.id} data={buildSlideData(inm, pub, { ...pub.slides[0], template: t.id, hidden: on ? pub.slides[0].hidden : defaultHidden(t.id) })} width={gw} height={gh} /></span>
                  {t.rank < 2 && <span style={{ position: 'absolute', left: 12, top: 12, fontSize: 11.5, fontWeight: 700, padding: '4px 10px', borderRadius: 999, background: k.blue, color: '#fff' }}>{t.rank === 0 ? 'Hecha para esto' : 'Recomendada'}</span>}
                </span>
                <span style={{ display: 'block', padding: '12px 15px 14px' }}><span style={{ display: 'flex', justifyContent: 'space-between' }}><b style={{ fontSize: 15 }}>{t.nombre}</b><span style={{ fontSize: 12, color: k.mut }}>{t.fotos === 1 ? '1 foto' : `${t.fotos} fotos`}</span></span><span style={{ display: 'block', fontSize: 12.5, color: k.mut, marginTop: 4 }}>{t.desc}</span></span>
              </button>); })}
          </div>
        </main>
      )}

      {/* 3 · Editar */}
      {step === 'editar' && (
        <div style={{ flex: 1, display: 'flex', flexWrap: 'wrap', minHeight: 0 }}>
          {/* Panel izquierdo: la pantalla actual */}
          <aside style={{ flex: '1 1 340px', maxWidth: 340, borderRight: `1px solid ${k.line}`, display: 'flex', flexDirection: 'column' }}>
            <div style={{ padding: '14px 16px 0' }}><div style={{ fontSize: 12, color: k.mut }}>Estás editando</div><div style={{ fontSize: 16, fontWeight: 600 }}>Pantalla {c + 1}: {label(c)}</div></div>
            <div role="tablist" style={{ display: 'flex', gap: 2, padding: '8px 12px 0', borderBottom: `1px solid ${k.line}` }}>
              {([['diseno', 'Diseño', LayoutTemplate], ['datos', 'Datos', Database], ['fotos', 'Fotos', ImageIcon], ['estilo', 'Estilo', Palette]] as const).map(([id, l, Icon]) => (
                <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)} style={{ ...btn, display: 'flex', alignItems: 'center', gap: 6, height: 42, padding: '0 10px', fontSize: 13.5, fontWeight: 600, color: tab === id ? k.fg : k.mut, borderBottom: `2px solid ${tab === id ? k.fg : 'transparent'}`, marginBottom: -1 }}><Icon size={15} />{l}</button>
              ))}
            </div>
            <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px 20px' }}>
              {tab === 'diseno' && (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,minmax(0,1fr))', gap: 10 }}>
                  {slideTemplates.map((t) => { const on = slide.template === t.id; return (
                    <button key={t.id} onClick={() => P.setTemplate(c, t.id)} aria-pressed={on} title={t.nombre} style={{ ...btn, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
                      <span style={{ display: 'grid', placeItems: 'center', width: '100%', height: 88, borderRadius: 9, border: `2px solid ${on ? k.blue : 'transparent'}`, background: k.stage, lineHeight: 0 }}><Creative template={t.id} data={buildSlideData(inm, pub, { ...slide, template: t.id })} width={tw} height={th} /></span>
                      <span style={{ fontSize: 11.5, color: on ? k.fg : k.mut, fontWeight: on ? 600 : 400 }}>{t.nombre}</span>
                    </button>); })}
                </div>
              )}
              {tab === 'datos' && (<>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10, fontSize: 12.5 }}><span style={{ color: k.mut }}>Datos de la ficha {inm.ref}</span>{nHid > 0 && <button onClick={() => P.editSlide(c, { hidden: {} })} style={{ ...btn, fontWeight: 600, color: k.link }}>Mostrar {nHid === 1 ? 'el dato oculto' : `los ${nHid} ocultos`}</button>}</div>
                {tpl.uses.map((f) => { const hidden = !!slide.hidden[f], on = sel === f; return (
                  <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 8px 6px 6px', marginBottom: 5, borderRadius: 10, border: `1px solid ${on ? k.blue : k.line}`, background: on ? 'rgba(76,141,255,.08)' : 'transparent' }}>
                    <button onClick={() => toggleField(f)} aria-pressed={hidden} aria-label={`${hidden ? 'Mostrar' : 'Ocultar'} ${FIELD_LABELS[f].toLowerCase()}`} style={iconBtn({ width: 30, height: 30, color: hidden ? k.mut : k.fg })}>{hidden ? <EyeOff size={15} /> : <Eye size={15} />}</button>
                    <button onClick={() => setSel(hidden ? '' : f)} style={{ ...btn, flex: 1, minWidth: 0, opacity: hidden ? .45 : 1 }}><span style={{ display: 'block', fontSize: 11.5, color: k.mut }}>{FIELD_LABELS[f]}</span><span style={{ display: 'block', fontSize: 13.5, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', textDecoration: hidden ? 'line-through' : 'none' }}>{f === 'logo' ? 'Automático, claro u oscuro' : data.f[f]}</span></button>
                    {slide.overrides[f] != null && <span style={{ fontSize: 10.5, fontWeight: 600, padding: '2px 7px', borderRadius: 999, background: 'rgba(224,168,46,.18)', color: k.warn }}>Editado</span>}
                  </div>); })}
                <label style={{ display: 'flex', gap: 10, padding: '11px 12px', border: `1px solid ${k.line2}`, borderRadius: 12, marginTop: 12, fontSize: 12.5 }}>
                  <input type="checkbox" checked={pub.soloZona} onChange={() => P.edit((p) => ({ soloZona: !p.soloZona }))} style={{ accentColor: k.blue }} />
                  <span><b style={{ display: 'block' }}>Mostrar solo la zona en toda la publicación</b><span style={{ color: k.mut }}>«{inm.zona}» en vez de «{inm.direccion}».</span></span>
                </label>
              </>)}
              {tab === 'fotos' && (<>
                {tpl.fotos > 1 && (<div role="radiogroup" style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 14 }}>{Array.from({ length: tpl.fotos }, (_, i) => <button key={i} role="radio" aria-checked={i === slotSel} onClick={() => onSelect('foto' + i)} style={pill(i === slotSel)}>{slotName(i)}</button>)}</div>)}
                <div style={{ fontSize: 12.5, color: k.mut, marginBottom: 8 }}>¿Qué foto va en «{slotName(slotSel)}»?</div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,minmax(0,1fr))', gap: 10 }}>
                  {inm.fotos.map((p, i) => { const inSlot = resolveSlots(slide.slots, nF).slice(0, tpl.fotos).indexOf(i), on = inSlot === slotSel; return (
                    <button key={p.id} onClick={() => P.editSlide(c, (s) => ({ slots: assignPhoto(s.slots, nF, slotSel, i, tpl.fotos) }))} aria-pressed={on} aria-label={`Poner ${p.nombre} en esta pantalla`} style={{ ...btn, position: 'relative', aspectRatio: '4/3', borderRadius: 10, border: `2px solid ${on ? k.blue : 'transparent'}`, backgroundImage: `url("${p.url}")`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
                      <span style={{ position: 'absolute', left: 6, bottom: 6, fontSize: 11, fontWeight: 600, padding: '2px 7px', borderRadius: 6, background: 'rgba(0,0,0,.65)', color: '#fff' }}>{p.nombre}</span>
                    </button>); })}
                </div>
              </>)}
              {tab === 'estilo' && (<>
                <p style={{ fontSize: 12.5, color: k.mut, marginTop: 0 }}>Color y tipografía son iguales en todas las pantallas.</p>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,minmax(0,1fr))', gap: 8, marginBottom: 20 }}>{(Object.keys(THEMES) as ThemeId[]).map((t) => <button key={t} onClick={() => P.edit({ theme: t })} aria-pressed={pub.theme === t} style={{ ...btn, display: 'flex', alignItems: 'center', gap: 9, padding: 8, borderRadius: 11, border: `1.5px solid ${pub.theme === t ? k.blue : k.line2}`, fontSize: 13, fontWeight: 600 }}><span style={{ width: 36, height: 28, borderRadius: 7, background: `linear-gradient(90deg, ${THEMES[t].bg} 66%, ${THEMES[t].acc} 66%)`, border: `1px solid ${k.line2}` }} />{THEMES[t].label}</button>)}</div>
                {(Object.keys(TYPOS) as TypoId[]).map((t) => <button key={t} onClick={() => P.edit({ typo: t })} aria-pressed={pub.typo === t} style={{ ...btn, display: 'flex', justifyContent: 'space-between', width: '100%', marginBottom: 8, padding: '11px 12px', borderRadius: 11, border: `1.5px solid ${pub.typo === t ? k.blue : k.line2}` }}><span style={{ fontFamily: TYPOS[t].ff, fontWeight: TYPOS[t].fw, fontSize: 22, textTransform: TYPOS[t].tt }}>Ático con vistas</span><span style={{ fontSize: 12, color: k.mut }}>{TYPOS[t].label}</span></button>)}
              </>)}
            </div>
          </aside>

          {/* Centro: la pantalla, con sus vecinas, añadir y eliminar a mano */}
          <section style={{ ...stage, position: 'relative', flex: '999 1 480px', minWidth: 0, display: 'flex', flexDirection: 'column' }}>
            {addPanel('top')}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap', padding: '10px 16px 0' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <button onClick={() => goTo(c - 1)} disabled={c === 0} aria-label="Pantalla anterior" style={iconBtn({ border: `1px solid ${k.line2}`, background: k.panel, opacity: c === 0 ? .35 : 1 })}><ChevronLeft size={17} /></button>
                <span style={{ fontSize: 13.5, fontWeight: 600, minWidth: 118, textAlign: 'center' }}>Pantalla {c + 1} de {n}</span>
                <button onClick={() => goTo(c + 1)} disabled={c === n - 1} aria-label="Pantalla siguiente" style={iconBtn({ border: `1px solid ${k.line2}`, background: k.panel, opacity: c === n - 1 ? .35 : 1 })}><ChevronRight size={17} /></button>
                <button onClick={() => setAddOpen(addOpen === 'top' ? false : 'top')} disabled={full} style={{ ...btn, display: 'flex', alignItems: 'center', gap: 6, height: 34, padding: '0 12px 0 9px', marginLeft: 6, borderRadius: 9, background: k.prim, color: k.primFg, fontSize: 13, fontWeight: 600, opacity: full ? .4 : 1 }}><Plus size={16} />{full ? 'Máximo 10' : 'Añadir pantalla'}</button>
                {deleteBtn()}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 12.5, color: k.mut }}>{fmtName}</span>
                <button aria-label="Deshacer" onClick={P.undo} disabled={!P.canUndo} style={iconBtn({ opacity: P.canUndo ? 1 : .3 })}><Undo2 size={17} /></button>
                <button aria-label="Rehacer" onClick={P.redo} disabled={!P.canRedo} style={iconBtn({ opacity: P.canRedo ? 1 : .3 })}><Redo2 size={17} /></button>
              </div>
            </div>

            {/* Barra de edición: campo del texto seleccionado */}
            <div style={{ display: 'flex', justifyContent: 'center', padding: '10px 16px 0' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, width: 520, maxWidth: '100%', minHeight: 48, padding: '6px 8px 6px 14px', borderRadius: 13, border: `1px solid ${selKey || selFoto ? k.blue : k.line2}`, background: k.panel }}>
                {!selKey && !selFoto && <span style={{ fontSize: 13, color: k.mut }}>Haz clic en un texto o en una foto de la pantalla para cambiarlos.</span>}
                {selKey && (<>
                  <label htmlFor="estudio-sel" style={{ fontSize: 12.5, fontWeight: 600, color: k.link, whiteSpace: 'nowrap' }}>{FIELD_LABELS[selKey]}</label>
                  {READONLY_FIELDS.includes(selKey) ? <span style={{ flex: 1, fontSize: 13, color: k.mut }}>{selKey === 'precio' ? `${baseFields(inm, pub, slide).precio} (se cambia en la ficha)` : 'Automático'}</span>
                    : <input id="estudio-sel" value={data.f[selKey]} onChange={(e) => setField(selKey, e.target.value)} style={{ flex: 1, minWidth: 60, height: 34, padding: '0 10px', border: `1px solid ${k.line2}`, borderRadius: 8, fontSize: 14, outline: 0 }} />}
                  {slide.overrides[selKey] != null && <button onClick={() => resetField(selKey)} style={{ ...btn, fontSize: 12.5, fontWeight: 600, color: k.mut, padding: '0 8px' }}>Restaurar</button>}
                  <button onClick={() => toggleField(selKey)} style={{ ...btn, display: 'flex', alignItems: 'center', gap: 6, height: 34, padding: '0 10px', borderRadius: 8, border: `1px solid ${k.line2}`, fontSize: 12.5, fontWeight: 600 }}><EyeOff size={15} />Ocultar</button>
                </>)}
                {selFoto && <><b style={{ fontSize: 12.5, color: k.link }}>{slotName(slotSel)}</b><span style={{ flex: 1, fontSize: 13, color: k.mut }}>Elige la foto en el panel de la izquierda.</span></>}
                {(selKey || selFoto) && <button onClick={() => setSel('')} aria-label="Quitar selección" style={iconBtn({ width: 30, color: k.mut })}><X size={16} /></button>}
              </div>
            </div>

            <div style={{ flex: 1, display: 'flex', minHeight: 0, overflow: 'auto', padding: '16px 16px 10px' }}>
              <div style={{ margin: 'auto', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  {/* Pantalla anterior asomando */}
                  {c > 0 ? (
                    <button onClick={() => goTo(c - 1)} aria-label={`Ir a la pantalla ${c}: ${label(c - 1)}`} className="estudio-peek" style={{ ...btn, position: 'relative', width: 86, height: peekH, overflow: 'hidden', borderRadius: 8, display: 'flex', justifyContent: 'flex-end', alignItems: 'center', opacity: .5 }}>
                      <span style={{ lineHeight: 0, pointerEvents: 'none' }}><Creative template={pub.slides[c - 1].template} data={slideData[c - 1]} width={peekW} height={peekH} /></span>
                      <NumBadge n={c} style={{ left: 6, top: 6 }} />
                    </button>
                  ) : <span aria-hidden style={{ width: 86 }} />}
                  <div role="img" aria-label={`Pantalla ${c + 1} de ${n} en edición`} style={{ lineHeight: 0, boxShadow: `0 24px 60px rgba(0,0,0,.35), 0 0 0 1px ${k.line}` }}>
                    <Creative template={slide.template} data={data} width={cw} height={ch} editable selected={sel} onSelect={onSelect} />
                  </div>
                  {/* Columna derecha: siguiente pantalla o «Añadir después», y debajo «Eliminar pantalla N» apuntando a la actual */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 10, width: 86, height: ch }}>
                    {c < n - 1 ? (
                      <button onClick={() => goTo(c + 1)} aria-label={`Ir a la pantalla ${c + 2}: ${label(c + 1)}`} className="estudio-peek" style={{ ...btn, position: 'relative', flex: 1, minHeight: 0, width: 86, overflow: 'hidden', borderRadius: 8, display: 'flex', alignItems: 'center', opacity: .5 }}>
                        <span style={{ lineHeight: 0, pointerEvents: 'none' }}><Creative template={pub.slides[c + 1].template} data={slideData[c + 1]} width={peekW} height={peekH} /></span>
                        <NumBadge n={c + 2} style={{ right: 6, top: 6 }} />
                      </button>
                    ) : !full && (
                      <button onClick={() => setAddOpen(addOpen === 'top' ? false : 'top')} aria-label={`Añadir una pantalla después de la ${c + 1}`} style={sideBtn({ flex: 1, minHeight: 0, border: `1.5px dashed ${addOpen === 'top' ? k.blue : k.line2}`, background: k.glass })}>
                        <span style={{ width: 32, height: 32, borderRadius: '50%', background: k.prim, color: k.primFg, display: 'grid', placeItems: 'center' }}><Plus size={17} /></span>Añadir<br />después
                      </button>
                    )}
                    {n > 1 && (
                      <button onClick={removeCurrent} aria-label={`Eliminar la pantalla ${c + 1}: ${label(c)}`} style={sideBtn({ position: 'relative', flex: '0 0 auto', height: Math.min(160, Math.max(118, Math.round(ch * .36))), border: `1.5px solid ${k.danger}`, background: k.dangerBg, color: k.danger })}>
                        {/* Pico hacia la pantalla que se borra */}
                        <span aria-hidden style={{ position: 'absolute', left: -7, top: '50%', width: 12, height: 12, marginTop: -6, transform: 'rotate(45deg)', background: k.dangerBg, borderLeft: `1.5px solid ${k.danger}`, borderBottom: `1.5px solid ${k.danger}` }} />
                        <span style={{ display: 'flex', gap: 4 }}><ArrowLeft size={15} /><Trash2 size={15} /></span>
                        <span>Eliminar<br />pantalla {c + 1}</span>
                      </button>
                    )}
                  </div>
                </div>
                {/* Puntos para ver cuántas pantallas hay y saltar entre ellas */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div role="tablist" aria-label="Pantallas de la publicación" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    {pub.slides.map((s, i) => <button key={s.id} role="tab" aria-selected={i === c} aria-label={`Pantalla ${i + 1}: ${label(i)}`} onClick={() => goTo(i)} style={{ ...btn, width: i === c ? 28 : 16, height: 22, display: 'grid', placeItems: 'center' }}><span style={{ width: i === c ? 22 : 8, height: 8, borderRadius: 999, background: i === c ? k.blue : k.dotOff, transition: 'width .15s' }} /></button>)}
                  </div>
                  <b style={{ fontSize: 13 }}>{n === 1 ? '1 pantalla' : `${c + 1} de ${n}`}</b>
                  {n > 1 && <span aria-hidden style={{ width: 1, height: 18, background: k.line2 }} />}
                  {deleteBtn(true)}
                </div>
              </div>
            </div>

            {/* Estructura + tira de pantallas */}
            <div style={{ position: 'relative', borderTop: `1px solid ${k.line}`, background: k.bg, padding: '10px 16px 12px' }}>
              {addPanel('bottom')}
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px 22px', flexWrap: 'wrap', padding: '4px 0 12px', marginBottom: 10, borderBottom: `1px solid ${k.line}`, fontSize: 13 }}>
                <b style={{ fontSize: 13.5 }}>Tu publicación</b>
                <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 6, height: 34, padding: '0 11px', borderRadius: 9, background: k.chip, fontWeight: 600 }}><Check size={15} />Portada</span>
                  <span style={{ color: k.mut }}>+</span>
                  <span style={{ display: 'flex', alignItems: 'center', height: 34, borderRadius: 9, border: `1px solid ${k.line2}` }}>
                    <button onClick={P.removePhoto} disabled={!P.photoCount} aria-label="Quitar una foto" style={iconBtn({ opacity: P.photoCount ? 1 : .35 })}>−</button>
                    <span aria-live="polite" style={{ minWidth: 74, textAlign: 'center', fontWeight: 600 }}>{P.photoCount === 0 ? 'Sin fotos' : P.photoCount === 1 ? '1 foto' : `${P.photoCount} fotos`}</span>
                    <button onClick={() => P.addPhoto(nF)} disabled={full} aria-label="Añadir una foto" style={iconBtn({ opacity: full ? .35 : 1 })}>+</button>
                  </span>
                  <span style={{ color: k.mut }}>+</span>
                  <button role="switch" aria-checked={P.hasClosing} onClick={P.toggleClosing} style={{ ...btn, display: 'flex', alignItems: 'center', gap: 8, height: 34, padding: '0 11px 0 8px', borderRadius: 9, border: `1px solid ${P.hasClosing ? k.fg : k.line2}`, background: P.hasClosing ? k.chip : 'transparent', fontWeight: 600 }}>
                    <span aria-hidden style={{ position: 'relative', width: 30, height: 18, borderRadius: 999, background: P.hasClosing ? k.blue : k.line2 }}><span style={{ position: 'absolute', top: 2, left: P.hasClosing ? 14 : 2, width: 14, height: 14, borderRadius: '50%', background: '#fff', transition: 'left .15s' }} /></span>{P.hasClosing ? 'Con cierre' : 'Sin cierre'}
                  </button>
                </span>
                <span style={{ color: k.mut, fontSize: 12.5 }}>{n === 1 ? 'Ahora es una sola imagen. Súmale fotos para hacer un carrusel.' : `Carrusel de ${n} imágenes.`}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, fontSize: 12.5 }}>
                <span style={{ color: k.mut }}>{n === 1 ? 'Pulsa la imagen para editarla.' : 'Pulsa una imagen para editarla. Arrastra para cambiar el orden.'}</span>
                <span style={{ display: 'flex', gap: 4 }}>
                  <button onClick={() => { P.move(c, c - 1); setCur(c - 1); }} disabled={c === 0} style={{ ...pill(false), height: 30, opacity: c === 0 ? .35 : 1 }}>← Mover</button>
                  <button onClick={() => { P.move(c, c + 1); setCur(c + 1); }} disabled={c === n - 1} style={{ ...pill(false), height: 30, opacity: c === n - 1 ? .35 : 1 }}>Mover →</button>
                  <button onClick={() => insertAfterCurrent(slide.template, resolveSlots(slide.slots, nF)[0])} disabled={full} style={{ ...pill(false), height: 30 }}>Duplicar</button>
                  {n > 1 && <button onClick={removeCurrent} style={{ ...pill(false), height: 30, color: k.danger }}>Eliminar pantalla {c + 1}</button>}
                </span>
              </div>
              <div style={{ display: 'flex', gap: 10, overflowX: 'auto', padding: 2 }}>
                {pub.slides.map((s, i) => (
                  <button key={s.id} onClick={() => goTo(i)} aria-pressed={i === c} draggable onDragStart={() => { dragFrom.current = i; }} onDragOver={(e) => e.preventDefault()} onDrop={onDrop(i)} title={label(i)} style={{ ...btn, flex: '0 0 auto', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5, width: 92, cursor: 'grab' }}>
                    <span style={{ position: 'relative', display: 'grid', placeItems: 'center', width: 92, height: 96, borderRadius: 10, border: `2px solid ${i === c ? k.blue : 'transparent'}`, background: k.stage }}>
                      <span style={{ lineHeight: 0, pointerEvents: 'none' }}><Creative template={s.template} data={slideData[i]} width={mw} height={mh} /></span>
                      <NumBadge n={i + 1} on={i === c} style={{ left: -6, top: -6 }} />
                    </span>
                    <span style={{ fontSize: 11, color: i === c ? k.fg : k.mut, fontWeight: i === c ? 600 : 400 }}>{label(i)}</span>
                  </button>
                ))}
                {!full && <button onClick={() => setAddOpen(addOpen === 'bottom' ? false : 'bottom')} style={{ ...btn, flex: '0 0 auto', width: 92, height: 96, borderRadius: 10, border: `1.5px dashed ${addOpen === 'bottom' ? k.blue : k.line2}`, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, fontSize: 12, fontWeight: 600 }}><Plus size={17} />Añadir pantalla</button>}
              </div>
            </div>
          </section>
        </div>
      )}

      {/* 4 · Publicar o descargar */}
      {step === 'publicar' && (
        <main style={{ padding: '28px 28px 120px', maxWidth: 680 }}>
          <h1 style={{ fontSize: 26, margin: 0, fontWeight: 600 }}>Publicar o descargar</h1>
          <p style={{ margin: '6px 0 22px', color: k.mut, fontSize: 14 }}>{n === 1 ? `Una imagen en ${fmtName}.` : `Un carrusel de ${n} imágenes en ${fmtName}.`} Puedes publicarlo o descargarlo.</p>
          <section style={{ border: `1px solid ${k.line}`, borderRadius: 16, padding: 16, background: k.panel, marginBottom: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><Sparkles size={17} /><h2 style={{ fontSize: 15, margin: 0 }}>Texto de la publicación</h2></div>
            <p style={{ fontSize: 12.5, color: k.mut, margin: '4px 0 12px' }}>La IA lo escribe con los datos que se ven en las pantallas. Revísalo antes de publicar.</p>
            <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginBottom: 12 }}>
              {(['instagram', 'facebook', 'linkedin', 'whatsapp'] as Canal[]).map((x) => <button key={x} aria-pressed={canal === x} onClick={() => setCanal(x)} style={pill(canal === x)}>{{ instagram: 'Instagram', facebook: 'Facebook', linkedin: 'LinkedIn', whatsapp: 'WhatsApp' }[x]}</button>)}
              <span aria-hidden style={{ width: 1, background: k.line2, margin: '4px' }} />
              {([['cercano', 'Cercano'], ['pro', 'Profesional'], ['lujo', 'Premium']] as [Tono, string][]).map(([x, l]) => <button key={x} aria-pressed={tono === x} onClick={() => setTono(x)} style={pill(tono === x)}>{l}</button>)}
            </div>
            {caption && <><textarea value={caption} onChange={(e) => setCaption(e.target.value)} rows={9} aria-label="Texto de la publicación" style={{ width: '100%', border: `1px solid ${k.line2}`, borderRadius: 10, padding: 11, font: 'inherit', fontSize: 13, lineHeight: 1.55 }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: k.mut, marginTop: 6 }}><span>{caption.length} caracteres</span><button onClick={() => navigator.clipboard?.writeText(caption)} style={{ ...btn, display: 'flex', gap: 6, fontWeight: 600, color: k.fg }}><Copy size={15} />Copiar</button></div></>}
            <button onClick={generateCaption} disabled={busy === 'caption'} style={{ ...btn, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, width: '100%', height: 40, marginTop: 10, borderRadius: 10, border: `1px solid ${k.line2}`, background: caption ? 'transparent' : k.prim, color: caption ? k.fg : k.primFg, fontSize: 13.5, fontWeight: 600 }}><Sparkles size={16} />{busy === 'caption' ? 'Escribiendo…' : caption ? 'Volver a generar' : 'Generar texto con IA'}</button>
          </section>
          <section style={{ border: `1px solid ${k.line}`, borderRadius: 16, padding: 16 }}>
            <h2 style={{ fontSize: 15, margin: '0 0 4px' }}>Descargar también para</h2>
            <p style={{ fontSize: 12.5, color: k.mut, margin: '0 0 8px' }}>Las mismas pantallas adaptadas a otro formato.</p>
            {(['story', 'fb', 'post', 'feed'] as FormatId[]).filter((f) => f !== pub.format).slice(0, 3).map((f) => (
              <label key={f} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '7px 2px', fontSize: 13.5 }}><input type="checkbox" checked={!!extra[f]} onChange={() => setExtra((e) => ({ ...e, [f]: !e[f] }))} style={{ accentColor: k.blue }} /><span style={{ flex: 1 }}>{f === 'post' ? 'Cuadrado' : f === 'feed' ? 'Instagram' : FORMATS[f].label} <span style={{ color: k.mut }}>{FORMATS[f].ratio}</span></span><span style={{ fontSize: 12, color: k.mut }}>{FORMATS[f].w}×{FORMATS[f].h}</span></label>
            ))}
          </section>
        </main>
      )}

      {/* Barra inferior: «Vista previa» siempre a mano; el botón de la derecha avanza */}
      {step !== 'inmueble' && (
        <div style={{ position: 'sticky', bottom: 0, zIndex: 30, display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap', padding: '12px 28px', borderTop: `1px solid ${k.line}`, background: k.glass, backdropFilter: 'blur(12px)' }}>
          <div style={{ flex: '1 1 200px', fontSize: 13, color: k.mut }}>{step === 'diseno' ? 'Al elegir un diseño pasas a editarlo.' : step === 'editar' ? (n === 1 ? 'Una imagen. Los cambios se guardan solos.' : `Carrusel de ${n}: estás en la ${c + 1}. Los cambios se guardan solos.`) : `${pantallas(n)} en ${fmtName}.`}</div>
          {step === 'diseno' && <FootBtn onClick={() => go('inmueble')}>Cambiar inmueble</FootBtn>}
          {step === 'editar' && <FootBtn onClick={() => go('diseno')}>Ver todos los diseños</FootBtn>}
          {step === 'publicar' && <FootBtn onClick={() => go('editar')}>Seguir editando</FootBtn>}
          {(step === 'editar' || step === 'publicar') && <FootBtn onClick={() => { setPv(step === 'editar' ? c : 0); setPvOpen(true); }}><Eye size={16} />Vista previa</FootBtn>}
          {step === 'diseno' && <FootBtn primary onClick={() => go('editar')}>Editar «{tplName(pub.slides[0].template)}»</FootBtn>}
          {step === 'editar' && <FootBtn primary onClick={() => go('publicar')}>Publicar o descargar</FootBtn>}
          {step === 'publicar' && <>
            <FootBtn onClick={save} disabled={!!busy}>Guardar en la ficha</FootBtn>
            <FootBtn onClick={download} disabled={!!busy}><Download size={16} />{busy === 'export' ? 'Generando…' : `Descargar ${nImages === 1 ? '1 imagen' : `${nImages} imágenes`}`}</FootBtn>
            <FootBtn primary onClick={publish} disabled={!!busy}><Send size={16} />{busy === 'publish' ? 'Publicando…' : 'Publicar en Instagram'}</FootBtn>
          </>}
        </div>
      )}

      {/* Vista previa en un móvil, deslizable como en Instagram */}
      {pvOpen && (
        <div role="dialog" aria-modal="true" aria-label="Vista previa" style={{ position: 'fixed', inset: 0, zIndex: 60, display: 'grid', placeItems: 'center', background: 'rgba(0,0,0,.6)' }} onClick={() => setPvOpen(false)}>
          <div onClick={(e) => e.stopPropagation()} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, color: '#fff', fontWeight: 600 }}>{n === 1 ? 'Así se verá publicada' : `Así se verá el carrusel de ${n}`}<button onClick={() => setPvOpen(false)} style={{ ...btn, display: 'flex', gap: 6, alignItems: 'center', height: 34, padding: '0 12px', borderRadius: 9, background: 'rgba(255,255,255,.14)', color: '#fff', fontSize: 13 }}><X size={15} />Cerrar</button></div>
            <div style={{ width: phoneW, borderRadius: 34, background: k.panel, padding: '14px 0 16px', boxShadow: '0 30px 70px rgba(0,0,0,.25)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '0 14px 10px', fontSize: 13 }}><span style={{ width: 30, height: 30, borderRadius: '50%', background: '#0A0A0A', color: '#fff', fontSize: 7, display: 'grid', placeItems: 'center' }}>RHB</span><b>rehabinco</b><span style={{ color: k.mut }}>{inm.barrio}</span></div>
              <div style={{ position: 'relative', lineHeight: 0 }}>
                <Creative template={pub.slides[pv].template} data={slideData[pv]} width={phoneW} height={phoneH} />
                {n > 1 && <>
                  <span style={{ position: 'absolute', right: 10, top: 10, fontSize: 11.5, fontWeight: 600, lineHeight: 1, padding: '5px 9px', borderRadius: 999, background: 'rgba(0,0,0,.6)', color: '#fff' }}>{pv + 1}/{n}</span>
                  {pv > 0 && <button onClick={() => setPv(pv - 1)} aria-label="Anterior" style={iconBtn({ position: 'absolute', left: 8, top: '50%', transform: 'translateY(-50%)', borderRadius: '50%', background: 'rgba(255,255,255,.92)', color: '#0A0A0A', width: 30, height: 30 })}><ChevronLeft size={16} /></button>}
                  {pv < n - 1 && <button onClick={() => setPv(pv + 1)} aria-label="Siguiente" style={iconBtn({ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', borderRadius: '50%', background: 'rgba(255,255,255,.92)', color: '#0A0A0A', width: 30, height: 30 })}><ChevronRight size={16} /></button>}
                </>}
              </div>
              {n > 1 && <div style={{ display: 'flex', justifyContent: 'center', gap: 5, padding: '10px 0 2px' }}>{pub.slides.map((s, i) => <button key={s.id} onClick={() => setPv(i)} aria-label={`Ver pantalla ${i + 1}`} style={{ ...btn, width: i === pv ? 16 : 6, height: 6, borderRadius: 999, background: i === pv ? k.blue : k.line2 }} />)}</div>}
              <div style={{ padding: '8px 14px 0', fontSize: 12.5, lineHeight: 1.45, maxHeight: 74, overflow: 'hidden' }}><b>rehabinco</b> <span style={{ color: caption ? k.fg : k.mut, whiteSpace: 'pre-line' }}>{caption || 'Aquí irá el texto de la publicación.'}</span></div>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div role="status" style={{ position: 'fixed', left: '50%', bottom: 90, transform: 'translateX(-50%)', zIndex: 70, display: 'flex', alignItems: 'center', gap: 9, padding: '11px 16px', borderRadius: 12, background: k.prim, color: k.primFg, fontSize: 13, fontWeight: 600 }}>
          <Check size={16} />{toast.msg}
          {toast.undo && <button onClick={() => { P.undo(); setToast(null); }} style={{ ...btn, marginLeft: 6, height: 28, padding: '0 10px', borderRadius: 7, border: '1px solid currentColor', fontSize: 12.5, fontWeight: 700 }}>Deshacer</button>}
        </div>
      )}

      {/* Lienzos fuera de pantalla para exportar a tamaño real (ancho/2 × pixelRatio 2) */}
      {step === 'publicar' && (
        <div aria-hidden style={{ position: 'fixed', left: -99999, top: 0, pointerEvents: 'none' }}>
          {formatsOut.map((f) => pub.slides.map((s, i) => (
            <div key={f + s.id} ref={(el) => { (exportRefs.current[f] ??= [])[i] = el; }}>
              <Creative template={s.template} data={slideData[i]} width={FORMATS[f].w / 2} height={FORMATS[f].h / 2} />
            </div>
          )))}
        </div>
      )}
    </div>
  );
}

function NumBadge({ n, on, style }: { n: number; on?: boolean; style: CSSProperties }) {
  return <span style={{ position: 'absolute', width: 22, height: 22, borderRadius: '50%', background: on ? k.blue : k.panel, color: on ? '#fff' : k.fg, border: `1px solid ${k.line2}`, fontSize: 11.5, fontWeight: 700, lineHeight: 1, display: 'grid', placeItems: 'center', ...style }}>{n}</span>;
}

function FootBtn({ children, onClick, primary, disabled }: { children: ReactNode; onClick: () => void; primary?: boolean; disabled?: boolean }) {
  return <button onClick={onClick} disabled={disabled} style={{ ...btn, display: 'flex', alignItems: 'center', gap: 8, height: 42, padding: '0 18px', borderRadius: 11, fontSize: 14, fontWeight: 600, opacity: disabled ? .5 : 1, background: primary ? k.prim : k.panel, color: primary ? k.primFg : k.fg, border: `1px solid ${primary ? k.prim : k.line2}` }}>{children}</button>;
}

function ThemeDots({ value, onPick }: { value: ThemeId; onPick: (t: ThemeId) => void }) {
  return (
    <div role="radiogroup" aria-label="Color" style={{ display: 'flex', gap: 5 }}>
      {(Object.keys(THEMES) as ThemeId[]).map((t) => (
        <button key={t} role="radio" aria-checked={value === t} aria-label={`Color ${THEMES[t].label}`} title={THEMES[t].label} onClick={() => onPick(t)} style={{ ...btn, width: 32, height: 32, borderRadius: '50%', border: `2px solid ${value === t ? k.blue : 'transparent'}`, display: 'grid', placeItems: 'center' }}>
          <span style={{ width: 22, height: 22, borderRadius: '50%', background: THEMES[t].bg, border: `1px solid ${k.line2}`, display: 'grid', placeItems: 'center' }}><span style={{ width: 8, height: 8, borderRadius: '50%', background: THEMES[t].acc }} /></span>
        </button>
      ))}
    </div>
  );
}
