-- Estudio · tablas sugeridas (Supabase / Postgres)
create table if not exists public.publicaciones (
  id uuid primary key default gen_random_uuid(),
  propiedad_id uuid not null references public.propiedades (id) on delete cascade,
  autor_id uuid not null references public.profiles (id),
  -- Publication completa (reference/data.ts): objetivo, formato, color, tipografía, solo zona y la lista de pantallas.
  estado jsonb not null,
  n_pantallas int not null,
  objetivo text not null,
  formato text not null,
  -- Rutas en Storage de las imágenes exportadas, en orden: { "feed": ["publicaciones/<id>/feed_01.jpg", ...], "story": [...] }
  archivos jsonb not null default '{}'::jsonb,
  texto text,
  instagram_media_id text,
  publicada_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists publicaciones_propiedad_idx on public.publicaciones (propiedad_id, updated_at desc);
alter table public.publicaciones enable row level security;
-- TODO(Cursor): replicar las políticas de `propiedades` (admin ve todo; comercial, las de sus inmuebles).

-- Versiones de foto editadas con IA: el original nunca se pisa.
create table if not exists public.propiedad_foto_versiones (
  id uuid primary key default gen_random_uuid(),
  foto_id uuid not null,            -- TODO(Cursor): fk a la tabla real de fotos del inmueble
  herramientas text[] not null,     -- ['mejora','cielo','amueblar:nordico', ...]
  recreacion_virtual boolean not null default false,  -- true si se amuebló o vació: obliga a rotular la imagen
  storage_path text not null,
  creditos int not null default 0,
  autor_id uuid not null references public.profiles (id),
  created_at timestamptz not null default now()
);
