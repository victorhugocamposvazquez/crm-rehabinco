/**
 * Copiar a `app/api/estudio/publicar/route.ts`.
 *
 * Publica en Instagram una imagen suelta o un carrusel (2-10 imágenes) con la API de Instagram (Graph API de Meta).
 * Flujo de Meta para carrusel:
 *   1. Un contenedor por imagen:  POST /{ig-user-id}/media  { image_url, is_carousel_item: true }
 *   2. Contenedor del carrusel:   POST /{ig-user-id}/media  { media_type: 'CAROUSEL', children: 'id1,id2,…', caption }
 *   3. Publicar:                  POST /{ig-user-id}/media_publish  { creation_id }
 * Imagen suelta: paso 1 sin `is_carousel_item` y con `caption`, y luego el paso 3.
 *
 * Requisitos (comprobar en la documentación vigente de Meta antes de implementar):
 *   - Cuenta de Instagram profesional vinculada a una página de Facebook, y token con permiso de publicación.
 *   - `image_url` debe ser una URL PÚBLICA (Supabase Storage público o firmada con caducidad larga). JPEG.
 *   - Todas las imágenes del carrusel con la misma proporción (por eso el formato es de la publicación entera).
 *   - Máximo 10 imágenes.
 */
type Body = { publicacionId: string; imageUrls: string[]; caption: string };

const GRAPH = 'https://graph.facebook.com/v21.0'; // TODO(Cursor): versión vigente de la Graph API

async function post(path: string, params: Record<string, string>, token: string): Promise<{ id: string }> {
  const r = await fetch(`${GRAPH}/${path}`, { method: 'POST', body: new URLSearchParams({ ...params, access_token: token }) });
  const j = await r.json();
  if (!r.ok || !j.id) throw new Error(j?.error?.message ?? 'Error de Instagram');
  return j;
}

export async function POST(req: Request) {
  // TODO(Cursor): sesión de Supabase y permiso sobre la publicación.
  const { imageUrls, caption } = (await req.json()) as Body;
  const igUser = process.env.IG_USER_ID!, token = process.env.IG_ACCESS_TOKEN!; // TODO(Cursor): por agencia, desde ajustes
  if (!imageUrls?.length || imageUrls.length > 10) return Response.json({ error: 'Entre 1 y 10 imágenes' }, { status: 400 });
  try {
    let creationId: string;
    if (imageUrls.length === 1) {
      creationId = (await post(`${igUser}/media`, { image_url: imageUrls[0], caption }, token)).id;
    } else {
      const children: string[] = [];
      for (const url of imageUrls) children.push((await post(`${igUser}/media`, { image_url: url, is_carousel_item: 'true' }, token)).id);
      creationId = (await post(`${igUser}/media`, { media_type: 'CAROUSEL', children: children.join(','), caption }, token)).id;
    }
    // TODO(Cursor): Meta puede tardar en procesar los contenedores; si `media_publish` falla por estado, consultar
    // GET /{creationId}?fields=status_code hasta FINISHED antes de publicar.
    const published = await post(`${igUser}/media_publish`, { creation_id: creationId }, token);
    // TODO(Cursor): guardar published.id y la fecha en `publicaciones`.
    return Response.json({ id: published.id });
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 502 });
  }
}
