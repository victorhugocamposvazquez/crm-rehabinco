# Handoff: Estudio · publicaciones para redes (carrusel)

Repo: `victorhugocamposvazquez/crm-rehabinco` (Next.js 15 · Tailwind · Supabase). Rama sugerida: `feature/estudio`.
Módulo nuevo en el menú, grupo **Captación**, debajo de *Inmuebles*: **Estudio**.

**Qué hace:** a partir de un inmueble crea una publicación para redes. Puede ser una imagen suelta o un **carrusel de 2 a 10
pantallas**, que es el caso principal. Las pantallas se rellenan solas con las fotos y los datos de la ficha. Al final se
**publica en Instagram** o se **descarga la secuencia completa**.

> Sustituye al paquete anterior del Estudio. Cambió el flujo: ya no hay «una creatividad», hay una **publicación con varias pantallas**.

## Ficheros

| Fichero | Qué es | Estado |
|---|---|---|
| `Estudio.dc.html` + `support.js` + `assets/` | Prototipo navegable, con versión clara y oscura (tweak «tema»). Servir con un servidor estático. | Referencia visual |
| `reference/config.ts` | Formatos, colores, tipografías, objetivos y catálogo de 17 diseños (incluye «Solo foto» y «Contacto») | Listo |
| `reference/templates.tsx` | Motor de plantillas: componente `<Creative>` | Listo |
| `reference/data.ts` | Modelo `Publication` / `Slide`, `buildSlideData()` y utilidades de fotos | Listo, falta mapear columnas reales |
| `reference/usePublication.ts` | Estado de la publicación con deshacer / rehacer, añadir / eliminar / mover pantallas, fotos y cierre | Listo |
| `reference/EstudioWizard.tsx` | Asistente completo de 4 pasos | Funciona; estilos en línea por adaptar a `components/ui` y a los tokens claro / oscuro |
| `reference/exportCreative.ts` | Exportación de todas las pantallas a JPEG a tamaño real | Listo |
| `reference/publishInstagram.route.ts` | Ruta que publica imagen o carrusel en Instagram (Graph API de Meta) | Esqueleto: falta token, cuenta y verificar contra la doc de Meta |
| `reference/caption.ts` + `caption.route.ts` | Texto de la publicación con IA (solo datos visibles) | Falta conectar el modelo en `generateText` |
| `reference/estudio.css` | Hover de selección y de las pantallas vecinas | Listo |
| `reference/publicaciones.sql` | Tablas `publicaciones` y `propiedad_foto_versiones` | Falta RLS y fk de fotos |
| `screenshots/` | Capturas de `reference/` ejecutándose | — |

**Comprobado antes de entregar:** `reference/` compila con `tsc --strict` y se ejecutó en Chromium (esbuild):
- galería de la imagen principal;
- añadir una pantalla desde el lateral, «+ foto» y cierre (4 pantallas);
- eliminar y «Deshacer» desde el aviso;
- editar un texto;
- vista previa;
- texto de respaldo;
- «Publicar en Instagram» con `onPublish` simulado: devolvió 4 JPEG de 1080×1350 y la plantilla de cada pantalla.

**No comprobado:**
- la integración en el repo real (Next 15, `next/font`, Supabase, tu Tailwind);
- la llamada real a Instagram;
- Safari y móvil.

## Dónde va cada cosa

```
app/(dashboard)/estudio/page.tsx          ← server component: carga inmuebles y pinta <EstudioWizard>
app/api/estudio/caption/route.ts          ← reference/caption.route.ts
app/api/estudio/publicar/route.ts         ← reference/publishInstagram.route.ts
components/estudio/EstudioWizard.tsx
components/estudio/templates.tsx
lib/estudio/{config,data,usePublication,exportCreative,caption}.ts
app/globals.css                           ← añadir reference/estudio.css
```
**Entradas al módulo:**
- **Item de menú Estudio:** abre en el paso 1.
- **Botón «Crear publicación»** en la ficha y en la tarjeta del inmueble: lleva a `/estudio?inmueble=<id>`. Pasa `initialInmuebleId` y se abre en el paso 2.

**Dependencias:** `npm i html-to-image`. `lucide-react` ya está en el repo.

**Fuentes:** van con variables CSS de `next/font`:
```ts
import { Inter, Fraunces, Bebas_Neue, JetBrains_Mono } from 'next/font/google';
const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const fraunces = Fraunces({ subsets: ['latin'], style: ['normal', 'italic'], variable: '--font-fraunces' });
const bebas = Bebas_Neue({ subsets: ['latin'], weight: '400', variable: '--font-bebas' });
const jetbrains = JetBrains_Mono({ subsets: ['latin'], variable: '--font-jetbrains' });
// <html className={`${inter.variable} ${fraunces.variable} ${bebas.variable} ${jetbrains.variable}`}>
```

## Modelo de datos

```ts
type Publication = { goal; format; theme; typo; soloZona; slides: Slide[] }   // se guarda en publicaciones.estado (jsonb)
type Slide = { id; template; hidden; overrides; slots }                        // cada pantalla, en orden
```
**Qué es de la publicación entera:**
- **Formato.** Instagram exige la misma proporción en todo el carrusel.
- **Color, tipografía, objetivo y «solo zona».** Así la publicación se ve como una sola pieza.

**Qué es de cada pantalla:**
- su diseño;
- los datos ocultos;
- los textos retocados;
- qué foto va en cada hueco.

`buildSlideData(inmueble, publication, slide)` une todo en lo que pinta `<Creative>`.

### Mapeo desde `propiedades` (`InmuebleEstudio` en `data.ts`)

| Campo | Origen | Nota |
|---|---|---|
| `ref`, `titulo`, `direccion`, `precio`, `m2`, `habitaciones`, `banos` | `propiedades` | — |
| `zona`, `barrio` | barrio + municipio | Por defecto se enseña la zona, no la calle |
| `precioAnterior` | último precio del histórico si es mayor | Sin él no aparece «Bajada de precio» |
| `energia` | letra del certificado | Si es null no se pinta |
| `agente` | `profiles` del comercial (nombre, iniciales, color) | — |
| `fotos[]` | Storage, en el orden de la ficha | `nombre` = estancia; `tipo` ext / int. URL pública (ver «Publicar») |

**Datos de ejemplo:** el teléfono y la web están en `AGENCIA` (`data.ts`). La fecha de «Puertas abiertas» también es de
ejemplo. Llévalos a los datos de empresa y al calendario.

**El precio no se edita en el Estudio,** solo se puede ocultar: se cambia en la ficha.

## Flujo

El indicador de pasos enseña lo ya elegido y permite volver a cualquier paso. **«Vista previa» es un botón** de la barra
inferior (pasos 3 y 4), no un paso. El botón de la derecha de esa barra siempre avanza.

1. **Inmueble.** Elegirlo avanza solo.
2. **Diseño.** «¿Qué quieres anunciar?» (nuevo, bajada, exclusiva, puertas abiertas, vendido, reforma) y el diseño de la
   **imagen principal**. Aquí todavía es una sola imagen. El formato y el color se eligen en este paso.
3. **Editar.** Se entra con **una pantalla** y el carrusel se arma aquí:
   - **Estructura** («Tu publicación»):
     - Portada, siempre presente.
     - Contador de fotos `− N +`: cada + añade la siguiente foto que aún no está.
     - Interruptor «Sin cierre / Con cierre»: añade o quita la pantalla Contacto al final.
   - **Añadir pantalla** (foto o diseño con datos), siempre *después de la actual*, desde tres sitios:
     - el botón de arriba;
     - la tarjeta «+ Añadir después» pegada a la derecha de la pantalla (solo en la última);
     - la tira inferior.
   - **Eliminar pantalla N** desde tres sitios, siempre con el número para saber cuál se borra:
     - arriba;
     - debajo de la pantalla, junto a los puntos;
     - la tarjeta roja de la columna derecha, con un pico que apunta a la pantalla.

     No hay diálogo de confirmación: sale un aviso con **Deshacer**, visible 6 s. Con una sola pantalla no aparece eliminar.
   - **Orientación:**
     - Puntos bajo la pantalla, como en Instagram, que se pueden pulsar.
     - «2 de 4».
     - Las pantallas vecinas asoman atenuadas a los lados; pulsarlas lleva a esa pantalla.
     - Tira de miniaturas que se puede arrastrar para reordenar.
   - **Edición de la pantalla actual:**
     - Clic en un texto o una foto del lienzo para seleccionarlo.
     - Barra de edición encima del lienzo.
     - Panel izquierdo con las pestañas Diseño / Datos / Fotos / Estilo.
   - **Deshacer / rehacer** cubre todo, incluido añadir, eliminar y mover pantallas.
4. **Publicar.**
   - Texto con IA (red + tono).
   - «Descargar también para» (Story, Facebook, cuadrado).
   - Barra inferior: **Guardar en la ficha**, **Descargar N imágenes** y **Publicar en Instagram** (principal).

   **No hay descarga de pantallas sueltas:** quien quiera menos, las elimina.

## Plantillas (`templates.tsx`)

`<Creative template data width height />` es puro. La misma función pinta la miniatura, el lienzo, las vecinas, la vista
previa y la exportación, porque todo va en `%` y `em`. Reglas:

- Cada dato va en `x.fld('clave', estilo, …)`. Así se puede ocultar y seleccionar.
- Cada foto va en `x.pic(hueco, estilo)`.
- Para adaptar al formato se usan `x.tall` y `x.wide`. Comprueba siempre los 4 formatos.
- Para añadir una plantilla: entrada en `TEMPLATES` (con `fotos` y `uses`) y su función en `R`. Las de apoyo del carrusel
  llevan `slideOnly: true` y no salen en la galería de la imagen principal.

## Exportar y publicar

- **Exportar** (`exportSlides`): monta fuera de pantalla todas las pantallas a ancho/2 y exporta con `pixelRatio` 2, en
  JPEG. Las fotos deben servirse con CORS.
- **Publicar** (`publishInstagram.route.ts`): un contenedor por imagen, luego el contenedor CAROUSEL con el texto, y por
  último `media_publish`. Para una imagen suelta, un solo contenedor con el texto.
  - **Requisitos:** cuenta de Instagram profesional vinculada a una página, y token con permiso de publicación.
  - **Imágenes:** URLs **públicas** (sube primero los JPEG a Storage), misma proporción y máximo 10.
  - **Verificar** la versión y los parámetros en la documentación vigente de Meta, y el estado `FINISHED` del contenedor
    antes de publicar.
- **`onPublish`** en la página, por orden:
  1. sube `images[format]` a Storage y guarda la fila en `publicaciones`;
  2. llama a `/api/estudio/publicar` con las URLs públicas en orden y el texto;
  3. lanza un error si falla, y el asistente lo enseña.

## Texto con IA

`buildCaptionPrompt()` solo pasa los datos visibles en alguna pantalla. Falta `generateText()` en la ruta, con el
proveedor que ya use el copiloto. Si falla, se usa `captionFallback()`.

## Fotos con IA (segunda pestaña del prototipo)

Diseñado en `Estudio.dc.html`, pero sin código en este paquete. Los puntos clave:
- comparador antes / después;
- herramientas por tipo de foto;
- el original nunca se pisa (`propiedad_foto_versiones`);
- rótulo «Imagen recreada virtualmente» en las fotos amuebladas o vaciadas;
- las fotos editadas se usan automáticamente en las pantallas.

## Lista de comprobación

- [ ] `/estudio?inmueble=<id>` abre en el paso 2; `/estudio`, en el 1.
- [ ] Se empieza con 1 pantalla; `+ foto`, cierre, añadir y eliminar actualizan puntos, tira, vecinas y «N de M».
- [ ] Añadir siempre inserta después de la actual y la selecciona; eliminar deja en la anterior y se puede deshacer.
- [ ] Deshacer devuelve cada cambio; escribir seguido en un campo cuenta como un paso.
- [ ] Los 17 diseños se ven bien en los 4 formatos con un título largo y con un inmueble de 2 fotos.
- [ ] Ocultar un dato lo quita de esa pantalla en el lienzo, las miniaturas, la vista previa y la exportación.
- [ ] Las imágenes salen al tamaño exacto, en orden y con las fuentes correctas.
- [ ] Publicar un carrusel de 10 y una imagen suelta en una cuenta de pruebas.
- [ ] El texto generado no menciona datos ocultos; un comercial solo ve sus inmuebles; el precio no se edita.
