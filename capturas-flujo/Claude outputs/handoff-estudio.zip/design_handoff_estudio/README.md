# Handoff: Estudio de creatividades (y fotos con IA)

Repo: `victorhugocamposvazquez/crm-rehabinco` (Next.js 15 · Tailwind · shadcn-style · Supabase).
Módulo nuevo dentro del grupo **Captación** del menú, debajo de *Inmuebles*: `Estudio`.
Rama sugerida: `feature/estudio` desde `main`.

Qué hace: a partir de un inmueble del CRM genera imágenes para redes (Instagram post / feed / story, Facebook)
con plantillas que **se rellenan solas** con las fotos y los datos de la ficha. El usuario elige qué anuncia, un diseño,
oculta o retoca datos, decide qué foto va en cada hueco y descarga los PNG a tamaño real.

## Ficheros de este paquete

| Fichero | Qué es | Estado |
|---|---|---|
| `Estudio.dc.html` + `support.js` + `assets/` | Prototipo navegable (referencia visual y de comportamiento). Ábrelo con un servidor estático. | Diseño de referencia |
| `reference/config.ts` | Formatos, colores, tipografías, objetivos y catálogo de los 15 diseños | Listo |
| `reference/templates.tsx` | Motor de plantillas: componente `<Creative>` | Listo |
| `reference/data.ts` | Tipos (`InmuebleEstudio`, `CreativeState`) y `buildCreativeData()` | Listo, falta mapear columnas reales |
| `reference/useCreative.ts` | Estado con deshacer / rehacer | Listo |
| `reference/exportCreative.ts` | Exportación a PNG a 1080 px | Listo |
| `reference/EstudioWizard.tsx` | Asistente de 4 pasos completo | Funciona; estilos en línea por adaptar a `components/ui` |
| `reference/caption.ts` + `caption.route.ts` | Prompt y ruta del texto para la publicación | Falta conectar el modelo (`generateText`) |
| `reference/estudio.css` | Hover de selección en el editor | Listo |
| `reference/creatividades.sql` | Tablas sugeridas | Falta RLS y la fk de fotos |
| `screenshots/` | Capturas del código de `reference/` ejecutándose | — |

**Comprobado antes de entregar:** `reference/` compila con `tsc --strict` y se ejecutó en Chromium empaquetado con esbuild:
elegir inmueble y objetivo, cambiar la foto de un hueco, editar un texto, ocultar un dato, deshacer / rehacer, texto de
respaldo y exportación (PNG de 1080×1080 y 1080×1920 reales). **No comprobado:** dentro del repo real (Next 15, `next/font`,
Supabase, tu Tailwind), ni Safari / móvil.

## Dónde va cada cosa

```
app/(dashboard)/estudio/page.tsx            ← server component: carga inmuebles y pinta <EstudioWizard>
app/api/estudio/caption/route.ts            ← reference/caption.route.ts
components/estudio/EstudioWizard.tsx
components/estudio/templates.tsx
lib/estudio/{config,data,useCreative,exportCreative,caption}.ts
app/globals.css                             ← añadir el contenido de reference/estudio.css
```
Entradas al módulo: item de menú **Estudio** (abre en el paso 1) y botón **Crear creatividad** en la ficha y en la tarjeta
del inmueble → `/estudio?inmueble=<id>` (abre en el paso 2 con el inmueble elegido: pasar `initialInmuebleId`).

Dependencias: `npm i html-to-image` (`lucide-react` ya está en el repo).

### Fuentes
Las plantillas usan variables CSS. En `app/layout.tsx`:
```ts
import { Inter, Fraunces, Bebas_Neue, JetBrains_Mono } from 'next/font/google';
const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const fraunces = Fraunces({ subsets: ['latin'], style: ['normal', 'italic'], variable: '--font-fraunces' });
const bebas = Bebas_Neue({ subsets: ['latin'], weight: '400', variable: '--font-bebas' });
const jetbrains = JetBrains_Mono({ subsets: ['latin'], variable: '--font-jetbrains' });
// <html className={`${inter.variable} ${fraunces.variable} ${bebas.variable} ${jetbrains.variable}`}>
```
Si el CRM ya carga Inter con otra variable, cambia solo `FONT.sans` en `config.ts`.

## Datos

`InmuebleEstudio` (en `data.ts`) es lo único que el Estudio necesita de `propiedades`. Hay que escribir el mapeo en el
server component de la página:

| Campo | Origen esperado | Nota |
|---|---|---|
| `ref`, `titulo`, `direccion`, `precio`, `m2`, `habitaciones`, `banos` | `propiedades` | — |
| `zona`, `barrio` | barrio + municipio | Se usa cuando «Mostrar solo la zona» está activo (por defecto sí) |
| `precioAnterior` | último precio del histórico, si es mayor que el actual | Sin él no aparece el objetivo «Bajada de precio» |
| `energia` | letra del certificado | Si es null, el dato no se pinta |
| `agente` | `profiles` del comercial asignado (nombre, iniciales, color) | — |
| `fotos[]` | fotos del inmueble en Storage, en el orden de la ficha | `nombre` = estancia; `tipo` ext / int |

Teléfono, web y llamada a la acción están en la constante `AGENCIA` de `data.ts`: **son de ejemplo**, llévalos a los datos
de empresa de Ajustes. La fecha y hora de «Puertas abiertas» también son de ejemplo: deberían salir de una cita del calendario.

El **precio no se edita** en el Estudio (solo se puede ocultar): se cambia en la ficha, para que la pieza y el CRM no se
contradigan. El resto de textos se pueden retocar; lo retocado se guarda en `overrides` y se puede restaurar.

## Flujo (4 pasos)

El indicador de pasos enseña lo ya elegido en cada paso y permite volver a cualquiera.

1. **Inmueble.** Rejilla de tarjetas. Elegir uno avanza solo al paso 2 y reinicia la pieza (conserva formato, color y tipografía).
2. **Diseño.** Primero «¿Qué quieres anunciar?» (nuevo, bajada de precio, exclusiva, puertas abiertas, vendido, reforma):
   fija la etiqueta de la pieza y ordena la galería (los diseños propios del objetivo salen primero como «Hecha para esto»,
   luego «Recomendada»; los de otro objetivo se ocultan). Después la galería, con cada diseño ya pintado con el inmueble.
   Filtros: Todos / Collage / Una foto, formato y color. Cada tarjeta dice cuántas fotos usa y avisa si el inmueble tiene
   menos. Elegir un diseño avanza al editor.
3. **Editar.** Tres zonas:
   - *Lienzo*: clic en un texto → se selecciona; clic en una foto → se selecciona el hueco; clic en el fondo → nada seleccionado.
   - *Barra de edición* justo encima del lienzo: campo de texto del dato seleccionado, **Ocultar** y **Restaurar** (si se retocó).
   - *Panel izquierdo*: **Datos** (solo los que usa el diseño, con ojo para ocultar y «Mostrar los ocultos»), **Fotos**
     (elegir hueco y qué foto va en él; si la foto ya estaba en otro hueco, se intercambian) y **Estilo** (color y tipografía).
   - *Tira inferior* con todos los diseños para cambiar de plantilla sin perder ediciones.
   - Deshacer / rehacer cubre: datos ocultos, textos, huecos de foto, color, tipografía, diseño y objetivo.
4. **Descargar.** La pieza en los 4 formatos con casilla para elegir cuáles; texto para la publicación (red + tono);
   **Descargar** baja los PNG y **Guardar en la ficha** llama a `onSave` (subir a Storage + fila en `creatividades`).

## Plantillas (`templates.tsx`)

`<Creative template data width height />` es puro y sirve igual para miniatura, lienzo y exportación porque todo va en
`%` y `em` sobre el `font-size` de la raíz (`min(W, H·0.8) / 22`). Reglas para tocar o añadir una:

- Cada dato va en `x.fld('clave', estilo, …)`. Eso es lo que permite ocultarlo y seleccionarlo. Un dato fuera de `x.fld` no se puede ocultar.
- Cada foto va en `x.pic(hueco, estilo)`.
- Superficie / dormitorios / baños en grande: `x.stats({ size })`. En huecos estrechos, `short: true`.
- `x.tall` (story, feed) y `x.wide` (Facebook) para recolocar. Comprobar siempre los 4 formatos.
- Al añadir una plantilla: entrada en `TEMPLATES` (`config.ts`) con `fotos` y `uses`, y su función en `R`.
- Los colores salen de `x.c` (tema). Nada de colores fijos salvo sobre foto (blanco) o papel (polaroids, nota).

Collages (por defecto, en claro): Galería, Mosaico, Moodboard, Tríptico, Formas, Tira de película, Polaroids.
Una foto: Portada, Exclusiva, Precio XXL, Ficha técnica. Propias de objetivo: Bajada de precio, Puertas abiertas, Vendido,
Antes y después.

Pendiente conocido: «Antes y después» usa la misma foto en blanco y negro como «antes»; necesita un segundo hueco para
la foto real de antes de la reforma. En formato Story, «Formas» deja aire en el centro.

## Exportar

`exportCreativePng(node, formato)` usa `html-to-image`. El asistente monta fuera de pantalla una `<Creative>` a 540 px de
ancho por formato marcado y exporta con `pixelRatio = 1080 / 540`.
**Requisito:** las fotos deben llegar con CORS (bucket público de Supabase o una ruta proxy `app/api/estudio/foto`); si no, falla.
Si en producción la exportación en cliente da problemas (Safari, fuentes), alternativa: ruta con `@vercel/og` / Satori no
sirve tal cual (no soporta `clip-path` ni `background-clip: text`); mejor Playwright en una función o mantener cliente.

## Texto para la publicación

`buildCaptionPrompt()` pasa al modelo **solo los datos visibles** en la pieza (si se ocultó el precio, no se menciona; si va
«solo zona», no sale la calle). Falta implementar `generateText()` en la ruta con el proveedor que ya use el copiloto.
Si falla, la ruta responde con `captionFallback()`.

## Fotos con IA (segunda pestaña del prototipo) — sin código en este paquete

Está diseñado en `Estudio.dc.html` (pestaña «Fotos con IA»); los efectos del prototipo son filtros CSS simulados. A construir:

- Lista de fotos del inmueble · comparador antes / después con deslizador · panel de herramientas.
- Herramientas: mejora automática, enderezar verticales, ampliar a 4K, cielo azul, atardecer, césped verde (solo exterior),
  amueblar virtualmente con estilo, vaciar estancia (solo interior), borrar objetos con pincel, difuminar caras y
  matrículas, marca de agua. Cada una con coste en créditos y contador mensual.
- **El original nunca se pisa**: cada resultado es una versión (`propiedad_foto_versiones` en el SQL).
- **Rotular «Imagen recreada virtualmente»** en fotos amuebladas o vaciadas, activado por defecto: evita publicidad engañosa.
- Una foto con versión editada se usa automáticamente en las creatividades (en `buildCreativeData`, usar la URL de la última versión).
- Proveedor de IA de imagen por decidir; todo en rutas de servidor.

## Base de datos

`reference/creatividades.sql`: tabla `creatividades` (estado completo en jsonb + rutas de los PNG) y
`propiedad_foto_versiones`. Faltan las políticas RLS (replicar las de `propiedades`) y la fk a la tabla real de fotos.

## Lista de comprobación para dar por buena la integración

- [ ] `/estudio?inmueble=<id>` abre en el paso 2 con ese inmueble; `/estudio` abre en el paso 1.
- [ ] Los 15 diseños se ven bien en los 4 formatos con un inmueble real de título largo y otro con 2 fotos.
- [ ] Ocultar un dato lo quita de la pieza, de la miniatura y de la exportación; «Mostrar los ocultos» lo devuelve.
- [ ] Cambiar la foto de un hueco no mueve las demás (salvo intercambio).
- [ ] Deshacer devuelve cada uno de los cambios anteriores; escribir seguido en un campo cuenta como un paso.
- [ ] Los PNG miden 1080×1080, 1080×1350, 1080×1920 y 1200×628 y llevan las fuentes correctas.
- [ ] El texto generado no menciona datos ocultos.
- [ ] Un comercial solo ve sus inmuebles; el precio no se puede editar.
