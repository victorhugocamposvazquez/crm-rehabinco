'use client';
/**
 * Exporta las pantallas a imagen a tamaño real (1080×1350, 1080×1080, 1080×1920, 1200×628).
 * Requiere `npm i html-to-image`. Las fotos tienen que venir con CORS (bucket público de Supabase o ruta proxy).
 */
import { toBlob } from 'html-to-image';
import { FORMATS, type FormatId } from './config';

/** `node` es la raíz que pinta <Creative> (lleva `data-estudio-creative`). JPEG: es lo que pide Instagram. */
export async function exportSlide(node: HTMLElement, format: FormatId, type: 'image/jpeg' | 'image/png' = 'image/jpeg'): Promise<Blob> {
  await document.fonts.ready;
  const blob = await toBlob(node, { pixelRatio: FORMATS[format].w / node.offsetWidth, cacheBust: true, type, quality: 0.92, backgroundColor: '#ffffff' });
  if (!blob) throw new Error('No se pudo generar la imagen');
  return blob;
}

/** Todas las pantallas en orden. `nodes[i]` = raíz de la pantalla i. */
export async function exportSlides(nodes: HTMLElement[], format: FormatId): Promise<Blob[]> {
  const out: Blob[] = [];
  for (const n of nodes) out.push(await exportSlide(n, format));
  return out;
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** «RHB-2026-0014_feed_01.jpg»: el número mantiene el orden del carrusel al subirlo a mano. */
export const slideFilename = (ref: string, format: FormatId, index: number) => `${ref}_${format}_${String(index + 1).padStart(2, '0')}.jpg`;
