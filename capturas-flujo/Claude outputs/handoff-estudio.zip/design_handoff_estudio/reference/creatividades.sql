-- Estudio de creatividades · tabla sugerida (Supabase / Postgres)
create table if not exists public.creatividades (
  id uuid primary key default gen_random_uuid(),
  propiedad_id uuid not null references public.propiedades (id) on delete cascade,
  autor_id uuid not null references public.profiles (id),
  -- CreativeState completo (reference/data.ts): objetivo, diseño, formato, color, tipografía, ocultos, textos editados, fotos por hueco.
  estado jsonb not null,
  -- Columnas duplicadas del jsonb para listar y filtrar sin abrirlo.
  objetivo text not null,
  plantilla text not null,
  -- Rutas en Storage de los PNG exportados: { "post": "creatividades/<id>/post.png", ... }
  archivos jsonb not null default '{}'::jsonb,
  texto_publicacion text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists creatividades_propiedad_idx on public.creatividades (propiedad_id, updated_at desc);

alter table public.creatividades enable row level security;
-- TODO(Cursor): replicar las políticas de `propiedades` (admin ve todo; comercial, las de sus inmuebles).

-- Versiones de foto editadas con IA: el original nunca se pisa.
create table if not exists public.propiedad_foto_versiones (
  id uuid primary key default gen_random_uuid(),
  foto_id uuid not null,            -- TODO(Cursor): fk a la tabla real de fotos del inmueble
  herramientas text[] not null,     -- ['mejora','cielo','amueblar:nordico', ...]
  recreacion_virtual boolean not null default false,  -- true si se amuebló o vació: obliga a rotular la imagen
  storage_path text not null,
  creditos int not null default 0,
  autor_id uuid not null references public.profiles (id),
  created_at timestamptz not null default now()
);
