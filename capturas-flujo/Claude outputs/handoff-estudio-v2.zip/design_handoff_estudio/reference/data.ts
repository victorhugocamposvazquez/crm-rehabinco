/**
 * Estudio · datos de una publicación.
 *
 * Una publicación es una lista ordenada de pantallas (1 = imagen suelta, 2-10 = carrusel).
 * Cada pantalla tiene su diseño, sus datos ocultos, sus textos retocados y sus fotos.
 * Formato, color, tipografía, objetivo y «solo zona» son de la publicación entera.
 */
import { GOALS, MAX_SLOTS, THEMES, TYPOS, type FieldKey, type FormatId, type GoalId, type TemplateId, type ThemeId, type TypoId } from './config';
import type { CreativeData, Spec } from './templates';

export type FotoInmueble = {
  id: string;
  /** URL pública (Supabase Storage). Debe servirse con CORS para exportar a PNG y ser accesible para Instagram al publicar. */
  url: string;
  /** Estancia: «Terraza», «Salón»… */
  nombre: string;
  tipo: 'ext' | 'int';
};

/** Lo que el Estudio necesita de `propiedades`. Mapea aquí tus columnas reales (ver README, «Datos»). */
export type InmuebleEstudio = {
  id: string; ref: string; titulo: string; direccion: string;
  /** «Monte Alto, A Coruña»: lo que se enseña con «solo zona». */
  zona: string; barrio: string;
  precio: number;
  /** Precio antes de la última bajada. Sin él no se ofrece «Bajada de precio». */
  precioAnterior?: number | null;
  m2: number; habitaciones: number; banos: number; energia?: string | null;
  agente: { nombre: string; iniciales: string; color: string };
  fotos: FotoInmueble[];
};

/** Datos de agencia que no salen de la ficha. TODO: llevar a los datos de empresa de Ajustes. */
export const AGENCIA = { telefono: '981 90 12 34', web: 'rehabinco.es' };

export type Slide = {
  id: string;
  template: TemplateId;
  hidden: Partial<Record<FieldKey, boolean>>;
  overrides: Partial<Record<FieldKey, string>>;
  /** Índice de foto por hueco. null = orden de la ficha. */
  slots: number[] | null;
};

/** Se guarda tal cual en `publicaciones.estado` (jsonb). */
export type Publication = {
  goal: GoalId;
  format: FormatId;
  theme: ThemeId;
  typo: TypoId;
  /** true = se enseña la zona y no la calle con número, en todas las pantallas. */
  soloZona: boolean;
  slides: Slide[];
};

let seq = 0;
const newId = () => `s${Date.now().toString(36)}${(seq++).toString(36)}`;

/** Datos ocultos por defecto según el tipo de pantalla. */
export function defaultHidden(t: TemplateId): Slide['hidden'] {
  if (t === 'contacto') return { ref: true };
  if (t === 'foto') return { pie: true };
  return { ref: true, tel: true, agente: true };
}

export function makeSlide(template: TemplateId, photo: number | null = null): Slide {
  return { id: newId(), template, hidden: defaultHidden(template), overrides: {}, slots: photo == null ? null : [photo, photo + 1, photo + 2, photo + 3, photo + 4] };
}

/** Se empieza siempre con UNA imagen: la principal. El carrusel se arma después. */
export function initialPublication(template: TemplateId = 'galeria'): Publication {
  return { goal: 'nuevo', format: 'feed', theme: 'blanco', typo: 'editorial', soloZona: true, slides: [makeSlide(template)] };
}

/** Foto de cada hueco, siempre con MAX_SLOTS entradas (si faltan fotos, se repiten). */
export function resolveSlots(slots: number[] | null, nFotos: number): number[] {
  const n = Math.max(1, nFotos);
  return Array.from({ length: MAX_SLOTS }, (_, i) => (slots?.[i] ?? i) % n);
}

/** Pone una foto en un hueco. Si ya estaba en otro hueco visible, se intercambian. */
export function assignPhoto(slots: number[] | null, nFotos: number, slot: number, photo: number, usedSlots: number): number[] {
  const sl = resolveSlots(slots, nFotos);
  const other = sl.slice(0, usedSlots).indexOf(photo);
  const prev = sl[slot];
  sl[slot] = photo;
  if (other >= 0 && other !== slot) sl[other] = prev;
  return sl;
}

/** Fotos ya usadas como pantalla «Solo foto» (para marcarlas como «Ya está» y no repetirlas). */
export function usedPhotoIndexes(pub: Publication, nFotos: number): number[] {
  return pub.slides.filter((s) => s.template === 'foto').map((s) => resolveSlots(s.slots, nFotos)[0]);
}

/** Siguiente foto del inmueble que todavía no está en el carrusel (empezando por la 2ª: la 1ª suele ir en la portada). */
export function nextUnusedPhoto(pub: Publication, nFotos: number): number {
  const used = usedPhotoIndexes(pub, nFotos);
  for (let j = 1; j <= nFotos; j++) if (!used.includes(j % nFotos)) return j % nFotos;
  return 1 % Math.max(1, nFotos);
}

const eur = (n: number) => n.toLocaleString('es-ES') + ' €';

/** Valor de cada dato sin ediciones (ficha, objetivo, agencia). */
export function baseFields(inm: InmuebleEstudio, pub: Publication, slide: Slide): Record<FieldKey, string> {
  const goal = GOALS.find((g) => g.id === pub.goal) ?? GOALS[0];
  const first = inm.fotos[resolveSlots(slide.slots, inm.fotos.length)[0]];
  return {
    badge: goal.badge, titulo: inm.titulo, zona: pub.soloZona ? inm.zona : inm.direccion, precio: eur(inm.precio),
    m2: String(inm.m2), hab: String(inm.habitaciones), banos: String(inm.banos), energia: inm.energia ?? '',
    ref: inm.ref, agente: inm.agente.nombre, tel: AGENCIA.telefono,
    cta: slide.template === 'vendido' || pub.goal === 'vendido' ? '¿Vendes tu casa? Te la valoramos gratis' : '¿Quieres visitarlo?',
    evento: 'Sáb 21 nov', evHora: '11:00 a 14:00', pie: first?.nombre ?? '', logo: '',
  };
}

/** Une ficha + publicación + pantalla en lo que necesita `<Creative>`. Pura: sirve en cliente y servidor. */
export function buildSlideData(inm: InmuebleEstudio, pub: Publication, slide: Slide): CreativeData {
  const base = baseFields(inm, pub, slide);
  const f = { ...base } as CreativeData['f'];
  (Object.keys(base) as FieldKey[]).forEach((k) => { const o = slide.overrides[k]; if (o != null) f[k] = o; });
  const antes = inm.precioAnterior && inm.precioAnterior > inm.precio ? inm.precioAnterior : null;
  f.antes = antes ? eur(antes) : '';
  f.dto = antes ? '-' + Math.round((1 - inm.precio / antes) * 100) + '%' : '';
  const sh = {} as CreativeData['sh'];
  (Object.keys(base) as FieldKey[]).forEach((k) => { sh[k] = !slide.hidden[k]; });
  if (!f.energia) sh.energia = false;
  const nHab = Number(f.hab) || 0, nBan = Number(f.banos) || 0;
  const specs = ([
    { k: 'm2', v: f.m2, u: 'm²', l: 'Superficie' },
    { k: 'hab', v: f.hab, u: nHab === 1 ? 'dormitorio' : 'dormitorios', l: 'Dormitorios' },
    { k: 'banos', v: f.banos, u: nBan === 1 ? 'baño' : 'baños', l: 'Baños' },
  ] as Spec[]).filter((s) => sh[s.k]);
  const order = resolveSlots(slide.slots, inm.fotos.length).map((i) => inm.fotos[i]);
  const millones = inm.precio >= 1e6;
  return {
    c: THEMES[pub.theme], ty: TYPOS[pub.typo], f, sh, specs,
    ph: order.map((p) => (p ? `url("${p.url}")` : 'none')), pf: order.map(() => 'none'), phName: order.map((p) => p?.nombre ?? ''),
    barrio: inm.barrio, m2: inm.m2,
    bigNum: millones ? (inm.precio / 1e6).toLocaleString('es-ES', { maximumFractionDigits: 2 }) : String(Math.round(inm.precio / 1000)),
    bigUnit: millones ? 'millones de euros' : 'mil euros',
  };
}

/** Nombre corto de una pantalla para la tira, los puntos y los avisos: «Portada», «Salón», «Contacto»… */
export function slideLabel(inm: InmuebleEstudio, slide: Slide, templateName: (t: TemplateId) => string): string {
  if (slide.template === 'foto') return inm.fotos[resolveSlots(slide.slots, inm.fotos.length)[0]]?.nombre ?? 'Foto';
  return templateName(slide.template);
}
